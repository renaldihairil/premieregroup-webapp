PREMIERE GROUP — folder audio
=================================

adzan.mp3
---------
Letakkan file audio adzan Anda di folder ini dengan nama PERSIS:

    assets/audio/adzan.mp3

Ketentuan:
  - Format .mp3 (paling kompatibel di semua HP/peramban).
  - Ukuran disarankan < 2 MB (mono, 96–128 kbps sudah cukup jernih).
  - Durasi bebas (adzan penuh ~2–4 menit tidak masalah — hanya diputar
    saat aplikasi sedang dibuka).

Cara kerja:
  - Saat waktu sholat tiba DAN aplikasi sedang terbuka, aplikasi memutar
    file ini secara otomatis + menampilkan notifikasi dalam aplikasi.
  - Notifikasi PUSH ke layar HP (aplikasi tertutup) tetap muncul, namun
    memakai nada notifikasi bawaan sistem — sistem operasi tidak
    mengizinkan aplikasi web memutar audio panjang di latar belakang.
    Adzan penuh diputar begitu pengguna membuka aplikasi dari notifikasi.
  - Jika file adzan.mp3 tidak ada, fitur tetap berjalan tanpa suara
    (tidak ada error).

Autoplay:
  - Peramban memblokir audio dari timer sebelum ada interaksi pengguna.
    Aplikasi sudah "membuka kunci" audio pada sentuhan/klik pertama
    pengguna di halaman, jadi pastikan pengguna sempat menyentuh layar
    setelah membuka aplikasi (hampir selalu terjadi secara alami).
